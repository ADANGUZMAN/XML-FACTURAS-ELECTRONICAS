package main;


import guis.Login;
import javafx.stage.Stage;
import utils.Viewer;
import utils.XMLTreeViewer;
import utils.XMLViewer;


public class Main {

	public static void main(String[] args) {
		Login app=new Login();
		app.setVisible(true);
		//XMLTreeViewer ap=new XMLTreeViewer();
		//ap.createUI();
		
	}

}
